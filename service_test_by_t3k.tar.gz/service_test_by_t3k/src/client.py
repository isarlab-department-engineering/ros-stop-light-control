#!/usr/bin/env python

# this an example of service client

import rospy,sys
from std_srvs.srv import SetBool

def client(data):
	rospy.wait_for_service('test')
	try:
		serv_test = rospy.ServiceProxy('test',SetBool)
		resp1 = serv_test(data)
		return resp1.message
	except rospy.ServiceException, e:
		print "error"

if __name__ == "__main__":
	if len(sys.argv) == 2:
		data = bool(sys.argv[1])
	else:
		sys.exit(1)
	print str(client(data))
	
