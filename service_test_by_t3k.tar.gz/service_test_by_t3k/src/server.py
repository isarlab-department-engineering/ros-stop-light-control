#!/usr/bin/env python

# this is an example of what inserted in master node 

import rospy
from std_srvs.srv import SetBool,SetBoolResponse

def call_serv(req):
	if req.data == True:
		print "gas"
		return SetBoolResponse(True,"gas")
	else:
		return SetBoolResponse(False,"no gas")

def server():
	rospy.init_node('test_server')
	s = rospy.Service('test',SetBool,call_serv)
	print "Ready"
	rospy.spin()
	
if __name__ == "__main__":
	try:
		server()
	except rospy.ROSInterruptException:
		pass
